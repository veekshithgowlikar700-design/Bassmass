# MASS BEATS — Android APK project

A starter Android app with a dark black-and-gold interface, generated drum-pulse preview, chant selection, intensity and duration controls, and Android Text-to-Speech chant playback.

## Build an APK using GitHub Actions
1. Create a new GitHub repository named `MASS-BEATS`.
2. Upload/extract every file in this ZIP into the repository root. Make sure `.github/workflows/build.yml` is included.
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build MASS BEATS APK** → **Run workflow** (or wait for the push build).
6. Open the completed run and download the **MASS-BEATS-APK** artifact. Extract it to find `app-debug.apk`.

## Current limitations
- This is a working starter/demo, not a finished AI music-generation studio.
- Drum sounds are synthesized as a simple rhythmic pulse; they are not sampled studio Chenda/Dhol/Thavil recordings.
- Chant playback uses the Android device's installed Text-to-Speech voice.
- It does not yet extract vocals/stems from an existing song, export a mixed audio file, or generate realistic AI choir vocals.
- No API keys or paid services are required for the included demo.
