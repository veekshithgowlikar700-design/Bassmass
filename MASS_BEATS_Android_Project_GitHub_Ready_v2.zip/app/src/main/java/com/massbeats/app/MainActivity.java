package com.massbeats.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.speech.tts.TextToSpeech;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import java.util.Locale;

public class MainActivity extends Activity {
    int bg = Color.rgb(10,10,12), panel = Color.rgb(25,24,25), gold = Color.rgb(224,177,78), muted = Color.rgb(166,160,148);
    TextToSpeech tts;
    volatile boolean playing = false;
    Thread beatThread;
    Spinner mantraSpinner, drumSpinner;
    SeekBar intensity, duration;
    TextView status, intensityLabel, durationLabel;
    AudioTrack track;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("en","IN")); });
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(26),dp(22),dp(28)); scroll.addView(root);
        TextView brand = text("MASS BEATS", 29, gold, true); root.addView(brand);
        TextView subtitle = text("CREATE YOUR ENTRY SOUND", 12, muted, true); subtitle.setPadding(0,dp(4),0,dp(22)); root.addView(subtitle);
        LinearLayout hero = card(); root.addView(hero);
        TextView tag = text("⚡  CINEMATIC AUDIO LAB", 12, gold, true); hero.addView(tag);
        TextView title = text("Make an entry.\nMake it MASS.", 27, Color.WHITE, true); title.setPadding(0,dp(12),0,dp(8)); hero.addView(title);
        TextView desc = text("Build a drum pulse and layer a spoken mantra.", 14, muted, false); hero.addView(desc);

        root.addView(section("01  •  CHOOSE YOUR CHANT"));
        mantraSpinner = spinner(new String[]{"Om Namah Shivaya","Jai Hanuman","Jai Mata Di","Har Har Mahadev","Custom mantra"}); root.addView(mantraSpinner);
        root.addView(section("02  •  DRUM STYLE"));
        drumSpinner = spinner(new String[]{"Indian Mass Drums","Chenda-inspired pulse","Dhol-inspired pulse","Thavil-inspired pulse"}); root.addView(drumSpinner);
        root.addView(section("03  •  INTENSITY"));
        intensityLabel = text("Power  •  75%",14,Color.WHITE,true); root.addView(intensityLabel);
        intensity = new SeekBar(this); intensity.setMax(100); intensity.setProgress(75); intensity.setProgressTintList(android.content.res.ColorStateList.valueOf(gold)); intensity.setThumbTintList(android.content.res.ColorStateList.valueOf(gold)); root.addView(intensity);
        intensity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){intensityLabel.setText("Power  •  "+p+"%");} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});
        root.addView(section("04  •  DURATION"));
        durationLabel = text("Length  •  30 seconds",14,Color.WHITE,true); root.addView(durationLabel);
        duration = new SeekBar(this); duration.setMax(5); duration.setProgress(2); duration.setProgressTintList(android.content.res.ColorStateList.valueOf(gold)); duration.setThumbTintList(android.content.res.ColorStateList.valueOf(gold)); root.addView(duration);
        duration.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){durationLabel.setText("Length  •  "+((p+1)*10)+" seconds");} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});
        Button generate = button("▶   GENERATE MASS BEAT"); root.addView(generate);
        Button chant = button("ॐ   PLAY CHANT"); root.addView(chant);
        Button stop = button("■   STOP AUDIO"); root.addView(stop);
        status = text("Ready when you are.",13,muted,false); status.setGravity(Gravity.CENTER); status.setPadding(0,dp(14),0,dp(10)); root.addView(status);
        TextView note = text("MASS BEATS • OFFLINE DEMO\nThis build synthesizes a basic drum pulse and uses your phone's text-to-speech voice for chants. It does not yet create studio-quality AI vocals or separate vocals from imported songs.",12,muted,false);
        note.setPadding(0,dp(22),0,0); root.addView(note);
        setContentView(scroll);
        generate.setOnClickListener(v -> startBeat());
        chant.setOnClickListener(v -> playChant());
        stop.setOnClickListener(v -> stopAudio());
    }
    void startBeat() {
        stopAudio(); playing=true; status.setText("Playing generated drum pulse…");
        final int power = Math.max(10,intensity.getProgress());
        final int seconds = (duration.getProgress()+1)*10;
        final int sampleRate=22050;
        beatThread = new Thread(() -> {
            try {
                int min = AudioTrack.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack(AudioManager.STREAM_MUSIC,sampleRate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min,4096),AudioTrack.MODE_STREAM);
                track.play();
                long end=System.currentTimeMillis()+seconds*1000L;
                int beat=0;
                while(playing && System.currentTimeMillis()<end) {
                    short[] data=new short[4096];
                    double gain=power/100.0;
                    for(int i=0;i<data.length;i++) {
                        double t=(beat*4096.0+i)/sampleRate;
                        double local=(i/(double)sampleRate);
                        double val=0;
                        // Kick-like low thump on beat 1 and 3; noisy tick on other beats.
                        if ((beat%4==0 || beat%4==2) && local<0.22) {
                            double freq=90*Math.exp(-local*13)+38;
                            val += Math.sin(2*Math.PI*freq*local)*Math.exp(-local*18)*0.95;
                        } else if(local<0.075) {
                            double noise=Math.sin((i+beat*17)*12.9898)*Math.cos((i+beat)*78.233);
                            val += noise*Math.exp(-local*45)*0.48;
                        }
                        val *= gain*0.75;
                        data[i]=(short)Math.max(-32767,Math.min(32767,val*32767));
                    }
                    track.write(data,0,data.length); beat++;
                }
            } catch(Exception e) { runOnUiThread(() -> status.setText("Audio playback unavailable on this device.")); }
            finally { playing=false; if(track!=null){try{track.stop();track.release();}catch(Exception ignored){} track=null;} runOnUiThread(() -> status.setText("Beat preview finished.")); }
        });
        beatThread.start();
    }
    void playChant() {
        if(tts==null) { status.setText("Text-to-speech is not ready."); return; }
        String selected=(String)mantraSpinner.getSelectedItem();
        String chant=selected.equals("Custom mantra") ? "Om Namah Shivaya" : selected;
        if(selected.equals("Jai Mata Di")) chant="Jai Mata Di";
        tts.speak(chant,TextToSpeech.QUEUE_FLUSH,null,"mass-chant");
        status.setText("Speaking chant: "+chant);
    }
    void stopAudio() {
        playing=false;
        if(tts!=null) tts.stop();
        if(track!=null){try{track.pause();track.flush();track.stop();track.release();}catch(Exception ignored){} track=null;}
        statusSafe("Audio stopped.");
    }
    void statusSafe(String s){ if(status!=null) status.setText(s); }
    LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(18),dp(18),dp(18),dp(18)); l.setBackground(round(panel,18)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(12); l.setLayoutParams(p); return l; }
    TextView section(String s){ TextView t=text(s,13,gold,true); t.setPadding(0,dp(22),0,dp(9)); return t; }
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    Spinner spinner(String[] values){ Spinner s=new Spinner(this); ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values){public View getView(int p,View c,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,c,parent);t.setTextColor(Color.WHITE);return t;}}; s.setAdapter(a); s.setBackground(round(panel,12)); s.setPadding(dp(10),dp(8),dp(10),dp(8)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.bottomMargin=dp(2); s.setLayoutParams(p); return s; }
    Button button(String label){ Button b=new Button(this); b.setText(label); b.setTextColor(bg); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(round(gold,14)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.topMargin=dp(10); b.setLayoutParams(p); return b; }
    android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){stopAudio();if(tts!=null){tts.shutdown();tts=null;}super.onDestroy();}
}
